//read through each env buffer of 512 samples @
// rate = 512/sampleRate(44100) * numOfSec;

var actx, sampsource, grainEnvSource, grGain, samprate, testosc, grRate;
function initAudio() {
  actx = new(window.AudioContext || window.webkitAudioContext)();
  samprate = actx.sampleRate;
  var grDurSec = 2.2;
  grRate = (512/samprate) * grDurSec;
  console.log(grRate);
  sampsource = actx.createBufferSource();
  grainEnvSource = actx.createBufferSource();
  grGain = actx.createGain();
  grGain.gain.value = 0;
  sampsource.connect(grGain);
  grGain.connect(actx.destination);
}

async function getFile(filepath) {
  const response = await fetch(filepath);
  const arrayBuffer = await response.arrayBuffer();
  const audioBuffer = await actx.decodeAudioData(arrayBuffer);
  return audioBuffer;
}
async function setupSample(filePath) {
  const sample = await getFile(filePath);
  return sample;
}

function loadSamp(filePath, bufsource) {
  setupSample(filePath)
    .then((sample) => {
      bufsource.buffer = sample;
    });
}

function playSamp(bufsource, playtime, sampleindextime, duration, rate, dest, loop) {
  bufsource.playbackRate.value = rate;
  bufsource.loop = loop;
  bufsource.connect(dest);
  bufsource.start(actx.currentTime + playtime, sampleindextime, duration);
}

var initAudioBtn = document.getElementById('initAudioBtn');
var loadSampBtn = document.getElementById('loadSampBtn');
var playSampBtn = document.getElementById('playSampBtn');
var playGrainBtn = document.getElementById('playGrainBtn');
initAudioBtn.addEventListener("click", function() { initAudio() }, false);
loadSampBtn.addEventListener("click", function() {
  loadSamp('FullmanFluctuations3_edit.wav', sampsource);
  loadSamp('/grainEnv/04_gEnv_hanning.wav', grainEnvSource)
}, false);
playSampBtn.addEventListener("click", function() { playSamp(sampsource, 0, 120, 24, 1, grGain, 0) }, false);
playGrainBtn.addEventListener("click", function() { playSamp(grainEnvSource, 0, 0, 9999, grRate, grGain.gain, 0) }, false);



/*
var osc1 = context.createOscillator();
var osc2 = context.createOscillator();
var gain = context.createGain();

osc1.frequency.value = 500;
osc2.frequency.value = 20;

osc1.connect(gain);
osc2.connect(gain.gain);

gain.connect(context.destination);

osc1.start();
osc2.start();


// create our AudioContext and Oscillator Nodes
var aCtx, sin1;

// Initialize both
aCtx = new (window.AudioContext || window.webkitAudioContext) ();
sin1 = aCtx.createOscillator();

// Configure sine Wave
sin1.frequency.value = 440;
sin1.type = 'sine';
sin1.start();

// Add sinewave to audio AudioContext
sin1.connect(aCtx.destination);

// create our AudioContext and Oscillator Nodes
var aCtx, sin1, gain;

// Initialize both
aCtx = new(window.AudioContext || window.webkitAudioContext)();
sin1 = aCtx.createOscillator();
gain = aCtx.createGain();

//get gui elements from html doc
var stbut1 = document.getElementById('st1');
var stpbut1 = document.getElementById('stp1');
var gainslider1 = document.getElementById('sld1');
var kickbut = document.getElementById('kick');
var snarebut = document.getElementById('snare');

// Configure sine Wave
sin1.frequency.value = 440;
sin1.type = 'sine';
sin1.start();
sin1.connect(gain);

//Create functions to start and stop sine waves
function startsin1() {
  gain.connect(aCtx.destination);
}

function stopsin1() {
  gain.disconnect(aCtx.destination);
}

//Add event listeners to respond to buttons
stbut1.addEventListener('click', startsin1);
stpbut1.addEventListener('click', stopsin1);

kickbut.addEventListener('click', playkick);
snarebut.addEventListener('click', playsnare);

//event listeners for sliders
gainslider1.oninput = function() {
  gain.gain.value = gainslider1.value;
}

*/
